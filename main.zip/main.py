# 1. Задача "Длина слова"

a = "Произвольная строка" # = 19 (18 символов и пробел)
print("Длина данной строки = {0}".format(len(a)))

# 2. Задача "Суммы и разности"

first = 24
second = 13

summa = first + second # 37
diff = first - second # 11

print("Сумма = {0} Разность = {1}".format(summa, diff))

# 3. Задача "Среднее арифметическое"

first = 75
second = 45
third = 23

mean = (first + second + third)/3 # 47.6
print("Среднее арифметическое {0}".format(mean))

# 4. Задача "Простые строчки".

first_string = "Вторник"
second_string = "Понедельник"

print("{0},{1}".format(first_string,second_string))

# 5. Задача "Сложная формула".

a = 50
b = 57
c = 38

f = (a * b) + (a * c) # = 4750

print("Результат сложной формулы = {0}".format(f))
